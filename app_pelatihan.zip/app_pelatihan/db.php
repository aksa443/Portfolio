<?php

class db
{
    private $koneksi;
    function __construct()
    {
        $this->koneksi = new mysqli("localhost", "root", "", "db_pelatihan");
    }

    function get_user($username, $password)
    {
        $data = $this->koneksi->query("select * from tbl_user where username='$username' and password='$password'");
        return $data;
    }

    // ================== MAHASISWA ==================
    function get_allMhs()
    {
        $data = $this->koneksi->query("select * from tbl_mahasiswa");
        return $data;
    }

    function add_mhs($nim, $nama, $alamat)
    {
        $this->koneksi->query("insert into tbl_mahasiswa(nim,nama,alamat) values('$nim','$nama','$alamat')");
        return true;
    }

    function update_mhs($nim, $nama, $alamat)
    {
        $this->koneksi->query("UPDATE tbl_mahasiswa SET nama = '$nama', alamat = '$alamat' WHERE nim='$nim'");
        return true;
    }

    function get_MhdByNim($nim)
    {
        $data = $this->koneksi->query("select * from tbl_mahasiswa where nim='$nim'");
        return $data;
    }

    function del_mhs($nim)
    {
        $this->koneksi->query("delete from tbl_mahasiswa where nim='$nim'");
        return true;
    }

    // ================== DOSEN ==================
    function get_allDosen()
    {
        $data = $this->koneksi->query("select * from tbl_dosen");
        return $data;
    }

    function add_dosen($kd_dosen, $nama, $alamat)
    {
        $this->koneksi->query("insert into tbl_dosen(kd_dosen,nama,alamat) values('$kd_dosen','$nama','$alamat')");
        return true;
    }

    function update_dosen($kd_dosen, $nama, $alamat)
    {
        $this->koneksi->query("UPDATE tbl_dosen SET nama = '$nama', alamat = '$alamat' WHERE kd_dosen='$kd_dosen'");
        return true;
    }

    function get_DosenByKode($kd_dosen)
    {
        $data = $this->koneksi->query("select * from tbl_dosen where kd_dosen='$kd_dosen'");
        return $data;
    }

    function del_dosen($kd_dosen)
    {
        $this->koneksi->query("delete from tbl_dosen where kd_dosen='$kd_dosen'");
        return true;
    }

    // ================== JADWAL ==================
    function get_allJadwal()
    {
        $sql = "SELECT j.*, d.nama AS nama_dosen, m.nama AS nama_matkul
            FROM tbl_jadwal j
            JOIN tbl_dosen d ON j.kd_dosen = d.kd_dosen
            JOIN tbl_matkul m ON j.kd_matkul = m.kd_matkul";
        $data = $this->koneksi->query($sql);
        return $data;
    }

    function get_JadwalById($id)
    {
        $sql = "SELECT j.*, d.nama AS nama_dosen, m.nama AS nama_matkul
            FROM tbl_jadwal j
            JOIN tbl_dosen d ON j.kd_dosen = d.kd_dosen
            JOIN tbl_matkul m ON j.kd_matkul = m.kd_matkul
            WHERE j.id = '$id'";
        $data = $this->koneksi->query($sql);
        return $data;
    }

    function add_jadwal($kd_dosen, $kd_matkul, $waktu, $ruang)
    {
        $this->koneksi->query("INSERT INTO tbl_jadwal(kd_dosen,kd_matkul,waktu,ruang) 
                           VALUES('$kd_dosen','$kd_matkul','$waktu','$ruang')");
        return true;
    }

    function update_jadwal($id, $kd_dosen, $kd_matkul, $waktu, $ruang)
    {
        $this->koneksi->query("UPDATE tbl_jadwal 
                           SET kd_dosen='$kd_dosen', kd_matkul='$kd_matkul', waktu='$waktu', ruang='$ruang'
                           WHERE id='$id'");
        return true;
    }

    function del_jadwal($id)
    {
        $this->koneksi->query("DELETE FROM tbl_jadwal WHERE id='$id'");
        return true;
    }

    // ================== KRS ==================
    function get_allKrs()
    {
        $sql = "SELECT k.*, 
                   mhs.nama AS nama_mhs,
                   s.semester,
                   j.waktu,
                   j.ruang,
                   mk.nama AS nama_matkul,
                   d.nama AS nama_dosen
            FROM tbl_krs k
            JOIN tbl_mahasiswa mhs ON k.nim = mhs.nim
            JOIN tbl_semester s ON k.kd_semester = s.kd_semester
            JOIN tbl_jadwal j ON k.id_jadwal = j.id
            JOIN tbl_matkul mk ON j.kd_matkul = mk.kd_matkul
            JOIN tbl_dosen d ON j.kd_dosen = d.kd_dosen";
        $data = $this->koneksi->query($sql);
        return $data;
    }

    function get_KrsById($id)
    {
        $sql = "SELECT k.*, 
                   mhs.nama AS nama_mhs,
                   s.semester,
                   j.waktu,
                   j.ruang,
                   mk.nama AS nama_matkul,
                   d.nama AS nama_dosen
            FROM tbl_krs k
            JOIN tbl_mahasiswa mhs ON k.nim = mhs.nim
            JOIN tbl_semester s ON k.kd_semester = s.kd_semester
            JOIN tbl_jadwal j ON k.id_jadwal = j.id
            JOIN tbl_matkul mk ON j.kd_matkul = mk.kd_matkul
            JOIN tbl_dosen d ON j.kd_dosen = d.kd_dosen
            WHERE k.id = '$id'";
        $data = $this->koneksi->query($sql);
        return $data;
    }

    function add_krs($nim, $id_jadwal, $kd_semester)
    {
        $this->koneksi->query("INSERT INTO tbl_krs(nim,id_jadwal,kd_semester) 
                           VALUES('$nim','$id_jadwal','$kd_semester')");
        return true;
    }

    function update_krs($id, $nim, $id_jadwal, $kd_semester)
    {
        $this->koneksi->query("UPDATE tbl_krs 
                           SET nim='$nim', id_jadwal='$id_jadwal', kd_semester='$kd_semester'
                           WHERE id='$id'");
        return true;
    }

    function del_krs($id)
    {
        $this->koneksi->query("DELETE FROM tbl_krs WHERE id='$id'");
        return true;
    }

    // ================== MATKUL ==================
    function get_allMatkul()
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_matkul");
        return $data;
    }

    function get_MatkulByKode($kd_matkul)
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_matkul WHERE kd_matkul='$kd_matkul'");
        return $data;
    }

    function add_matkul($kd_matkul, $nama, $sks)
    {
        $this->koneksi->query("INSERT INTO tbl_matkul(kd_matkul,nama,sks) 
                           VALUES('$kd_matkul','$nama','$sks')");
        return true;
    }

    function update_matkul($kd_matkul, $nama, $sks)
    {
        $this->koneksi->query("UPDATE tbl_matkul 
                           SET nama='$nama', sks='$sks'
                           WHERE kd_matkul='$kd_matkul'");
        return true;
    }

    function del_matkul($kd_matkul)
    {
        $this->koneksi->query("DELETE FROM tbl_matkul WHERE kd_matkul='$kd_matkul'");
        return true;
    }

    // ================== SEMESTER ==================
    function get_allSemester()
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_semester");
        return $data;
    }

    function get_SemesterByKode($kd_semester)
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_semester WHERE kd_semester='$kd_semester'");
        return $data;
    }

    function add_semester($kd_semester, $semester)
    {
        $this->koneksi->query("INSERT INTO tbl_semester(kd_semester,semester) 
                           VALUES('$kd_semester','$semester')");
        return true;
    }

    function update_semester($kd_semester, $semester)
    {
        $this->koneksi->query("UPDATE tbl_semester 
                           SET semester='$semester'
                           WHERE kd_semester='$kd_semester'");
        return true;
    }

    function del_semester($kd_semester)
    {
        $this->koneksi->query("DELETE FROM tbl_semester WHERE kd_semester='$kd_semester'");
        return true;
    }

    // ================== USER ==================
    function get_allUser()
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_user");
        return $data;
    }

    function get_UserById($id)
    {
        $data = $this->koneksi->query("SELECT * FROM tbl_user WHERE id='$id'");
        return $data;
    }

    function add_user($username, $password)
    {
        // kalau mau, bisa pakai md5()/password_hash, tapi disesuaikan dengan login
        $this->koneksi->query("INSERT INTO tbl_user(username,password) VALUES('$username','$password')");
        return true;
    }

    function update_user($id, $username, $password)
    {
        $this->koneksi->query("UPDATE tbl_user SET username='$username', password='$password' WHERE id='$id'");
        return true;
    }

    function del_user($id)
    {
        $this->koneksi->query("DELETE FROM tbl_user WHERE id='$id'");
        return true;
    }
}
