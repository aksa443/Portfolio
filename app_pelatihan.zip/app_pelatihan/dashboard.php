<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin 2 - Tables</title>

    <!-- Custom fonts for this template -->
    <link href="asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="asset/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="asset/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <div class="sidebar-heading">
                Interface
            </div>

            <!-- Nav Item - Master Data -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaster"
                    aria-expanded="true" aria-controls="collapseMaster">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Master</span>
                </a>
                <div id="collapseMaster" class="collapse" aria-labelledby="headingMaster" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Master Data</h6>
                        <a class="collapse-item" href="#" id="m_mahasiswa">Mahasiswa</a>
                        <a class="collapse-item" href="#" id="m_dosen">Dosen</a>
                        <a class="collapse-item" href="#" id="matkul">Mata Kuliah</a>
                        <a class="collapse-item" href="#" id="semester">Semester</a>
                        <a class="collapse-item" href="#" id="m_user">User</a>
                    </div>
                </div>
            </li>

            <!-- Nav Item - Transaksi -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTransaksi"
                    aria-expanded="true" aria-controls="collapseTransaksi">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Transaksi</span>
                </a>
                <div id="collapseTransaksi" class="collapse" aria-labelledby="headingTransaksi"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Data Transaksi:</h6>
                        <a class="collapse-item" href="#" id="jadwal">Jadwal</a>
                        <a class="collapse-item" href="#" id="krs">KRS</a>
                    </div>
                </div>
            </li>

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope fa-fw"></i>
                                <span class="badge badge-danger badge-counter">7</span>
                            </a>
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="messagesDropdown">
                                <h6 class="dropdown-header">
                                    Message Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_1.svg"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div class="font-weight-bold">
                                        <div class="text-truncate">Hi there! I am wondering if you can help me with a
                                            problem I've been having.</div>
                                        <div class="small text-gray-500">Emily Fowler · 58m</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_2.svg"
                                            alt="...">
                                        <div class="status-indicator"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">I have the photos that you ordered last month, how
                                            would you like them sent to you?</div>
                                        <div class="small text-gray-500">Jae Chun · 1d</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="img/undraw_profile_3.svg"
                                            alt="...">
                                        <div class="status-indicator bg-warning"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">Last month's report looks great, I am very happy with
                                            the progress so far, keep up the good work!</div>
                                        <div class="small text-gray-500">Morgan Alvarez · 2d</div>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img class="rounded-circle" src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                                            alt="...">
                                        <div class="status-indicator bg-success"></div>
                                    </div>
                                    <div>
                                        <div class="text-truncate">Am I a good boy? The reason I ask is because someone
                                            told me that people say this to all dogs, even if they aren't good...</div>
                                        <div class="small text-gray-500">Chicken the Dog · 2w</div>
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                            </div>
                        </li>

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Aries Ardyaksa</span>
                                <img class="img-profile rounded-circle"
                                    src="asset/img/undraw_profile.svg">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div id="contentData">
                    <div class="container-fluid">
                        <div>
                            <h1 class="h3 mb-4 text-gray-800">Welcome</h1>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2023</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="asset/vendor/jquery/jquery.min.js"></script>
    <script src="asset/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="asset/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="asset/js/sb-admin-2.min.js"></script>

    <!-- DataTables -->
    <script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="asset/js/demo/datatables-demo.js"></script>

    <!-- Custom AJAX & Sidebar Logic -->
    <script>
        $(document).ready(function() {

            // ===================== MENU MAHASISWA =====================
            $("#m_mahasiswa").click(function() {
                loadMhs();
            });

            $("#contentData").on("submit", "#formMhs", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'mahasiswa/mahasiswa.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadMhs();
                    }
                });
            });

            $("#contentData").on("click", "#deleteMhs", function() {
                var nim = $(this).attr("value");
                $.ajax({
                    url: 'mahasiswa/mahasiswa.php?action=delete',
                    type: 'post',
                    data: {
                        nim: nim
                    },
                    success: function(data) {
                        alert(data);
                        loadMhs();
                    }
                });
            });

            $("#contentData").on("click", "#editMhs", function() {
                var nim = $(this).attr("value");
                $.ajax({
                    url: 'mahasiswa/edit.php',
                    type: 'get',
                    data: {
                        nim: nim
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditMhs", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'mahasiswa/mahasiswa.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadMhs();
                    }
                });
            });


            // ===================== MENU DOSEN =====================
            $("#m_dosen").click(function() {
                loadDosen();
            });

            $("#contentData").on("submit", "#formDosen", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'dosen/dosen.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadDosen();
                    }
                });
            });

            $("#contentData").on("click", "#deleteDosen", function() {
                var kd_dosen = $(this).attr("value");
                $.ajax({
                    url: 'dosen/dosen.php?action=delete',
                    type: 'post',
                    data: {
                        kd_dosen: kd_dosen
                    },
                    success: function(data) {
                        alert(data);
                        loadDosen();
                    }
                });
            });

            $("#contentData").on("click", "#editDosen", function() {
                var kd_dosen = $(this).attr("value");
                $.ajax({
                    url: 'dosen/edit.php',
                    type: 'get',
                    data: {
                        kd_dosen: kd_dosen
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditDosen", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'dosen/dosen.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadDosen();
                    }
                });
            });


            // ===================== MENU JADWAL =====================
            $("#jadwal").click(function() {
                loadJadwal();
            });

            $("#contentData").on("submit", "#formJadwal", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'jadwal/jadwal.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadJadwal();
                    }
                });
            });

            $("#contentData").on("click", "#editJadwal", function() {
                var id = $(this).attr("value");
                $.ajax({
                    url: 'jadwal/edit.php',
                    type: 'get',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditJadwal", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'jadwal/jadwal.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadJadwal();
                    }
                });
            });

            $("#contentData").on("click", "#deleteJadwal", function() {
                if (!confirm("Yakin ingin menghapus jadwal ini?")) return;
                var id = $(this).attr("value");
                $.ajax({
                    url: 'jadwal/jadwal.php?action=delete',
                    type: 'post',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        alert(data);
                        loadJadwal();
                    }
                });
            });


            // ===================== MENU KRS =====================
            $("#krs").click(function() {
                loadKrs();
            });

            $("#contentData").on("submit", "#formKrs", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'krs/krs.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadKrs();
                    }
                });
            });

            $("#contentData").on("click", "#editKrs", function() {
                var id = $(this).attr("value");
                $.ajax({
                    url: 'krs/edit.php',
                    type: 'get',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditKrs", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'krs/krs.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadKrs();
                    }
                });
            });

            $("#contentData").on("click", "#deleteKrs", function() {
                if (!confirm("Yakin ingin menghapus data KRS ini?")) return;
                var id = $(this).attr("value");
                $.ajax({
                    url: 'krs/krs.php?action=delete',
                    type: 'post',
                    data: {
                        id: id
                    },
                    success: function(data) {
                        alert(data);
                        loadKrs();
                    }
                });
            });


            // ===================== MENU MATKUL =====================
            $("#matkul").click(function() {
                loadMatkul();
            });

            $("#contentData").on("submit", "#formMatkul", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'matkul/matkul.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadMatkul();
                    }
                });
            });

            $("#contentData").on("click", "#editMatkul", function() {
                var kd_matkul = $(this).attr("value");
                $.ajax({
                    url: 'matkul/edit.php',
                    type: 'get',
                    data: {
                        kd_matkul: kd_matkul
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditMatkul", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'matkul/matkul.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadMatkul();
                    }
                });
            });

            $("#contentData").on("click", "#deleteMatkul", function() {
                if (!confirm("Yakin ingin menghapus data matkul ini?")) return;
                var kd_matkul = $(this).attr("value");
                $.ajax({
                    url: 'matkul/matkul.php?action=delete',
                    type: 'post',
                    data: {
                        kd_matkul: kd_matkul
                    },
                    success: function(data) {
                        alert(data);
                        loadMatkul();
                    }
                });
            });


            // ===================== MENU SEMESTER =====================
            $("#semester").click(function() {
                loadSemester();
            });

            $("#contentData").on("submit", "#formSemester", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'semester/semester.php?action=save',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadSemester();
                    }
                });
            });

            $("#contentData").on("click", "#editSemester", function() {
                var kd_semester = $(this).attr("value");
                $.ajax({
                    url: 'semester/edit.php',
                    type: 'get',
                    data: {
                        kd_semester: kd_semester
                    },
                    success: function(data) {
                        $('#contentData').html(data);
                    }
                });
            });

            $("#contentData").on("submit", "#formEditSemester", function(e) {
                e.preventDefault();
                $.ajax({
                    url: 'semester/semester.php?action=edit',
                    type: 'post',
                    data: $(this).serialize(),
                    success: function(data) {
                        alert(data);
                        loadSemester();
                    }
                });
            });

            $("#contentData").on("click", "#deleteSemester", function() {
                if (!confirm("Yakin ingin menghapus data semester ini?")) return;
                var kd_semester = $(this).attr("value");
                $.ajax({
                    url: 'semester/semester.php?action=delete',
                    type: 'post',
                    data: {
                        kd_semester: kd_semester
                    },
                    success: function(data) {
                        alert(data);
                        loadSemester();
                    }
                });
            });

        }); // end document.ready

        // ===================== MENU USER =====================
        $("#m_user").click(function() {
            loadUser();
        });

        // simpan user
        $("#contentData").on("submit", "#formUser", function(e) {
            e.preventDefault();
            $.ajax({
                url: 'user/user.php?action=save',
                type: 'post',
                data: $(this).serialize(),
                success: function(data) {
                    alert(data);
                    loadUser();
                }
            });
        });

        // edit user - load form
        $("#contentData").on("click", "#editUser", function() {
            var id = $(this).attr("value");
            $.ajax({
                url: 'user/edit.php',
                type: 'get',
                data: {
                    id: id
                },
                success: function(data) {
                    $('#contentData').html(data);
                }
            });
        });

        // edit user - submit
        $("#contentData").on("submit", "#formEditUser", function(e) {
            e.preventDefault();
            $.ajax({
                url: 'user/user.php?action=edit',
                type: 'post',
                data: $(this).serialize(),
                success: function(data) {
                    alert(data);
                    loadUser();
                }
            });
        });

        // delete user
        $("#contentData").on("click", "#deleteUser", function() {
            if (!confirm("Yakin ingin menghapus user ini?")) return;
            var id = $(this).attr("value");
            $.ajax({
                url: 'user/user.php?action=delete',
                type: 'post',
                data: {
                    id: id
                },
                success: function(data) {
                    alert(data);
                    loadUser();
                }
            });
        });

        // ===================== FUNGSI LOAD =====================
        function loadMhs() {
            $.get('mahasiswa/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadDosen() {
            $.get('dosen/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadJadwal() {
            $.get('jadwal/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadKrs() {
            $.get('krs/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadMatkul() {
            $.get('matkul/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadSemester() {
            $.get('semester/list.php', function(data) {
                $('#contentData').html(data);
            });
        }

        function loadUser() {
            $.get('user/list.php', function(data) {
                $('#contentData').html(data);
            });
        }
    </script>

</body>

</html>