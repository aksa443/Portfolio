<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit User</h1>
    <p class="mb-4">Form untuk mengubah data user.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form User</h6>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">

            <?php
            include "../db.php";
            $id = $_GET['id'];
            $db = new db;

            $user = $db->get_UserById($id);
            $row = $user->fetch_array();
            ?>

            <form method="POST" id="formEditUser">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="username" value="<?php echo $row['username']; ?>">
                </div>
                <div class="form-group">
                    <label>Password (kosongkan jika tidak diubah)</label>
                    <!-- tidak diisi nilai lama, tetap kosong -->
                    <input type="password" class="form-control" name="password">
                </div>

                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>

            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>
