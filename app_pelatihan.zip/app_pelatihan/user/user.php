<?php
include "../db.php";
$db = new db;

switch ($_GET['action'])
{
    case 'save':

        $username = $_POST['username'];
        $password = $_POST['password'];

        $query = $db->add_user($username,$password);
        if ($query){
            echo "Simpan User Berhasil";
        } else {
            echo "Simpan User Gagal";
        }
    break;

    case 'edit':

        $id       = $_POST['id'];
        $username = $_POST['username'];
        $password = isset($_POST['password']) ? $_POST['password'] : '';

        if ($password === '' || $password === null) {
            // update tanpa ubah password
            $query = $db->update_user_without_password($id,$username);
        } else {
            // update username + password baru
            $query = $db->update_user($id,$username,$password);
        }

        if ($query){
            echo "Edit User Berhasil";
        } else {
            echo "Edit User Gagal";
        }
    break;

    case 'delete':

        $id = $_POST['id'];

        $query = $db->del_user($id);
        if ($query){
            echo "Hapus User Berhasil";
        } else {
            echo "Hapus User Gagal";
        }
    break;
}
?>
