<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">User</h1>
    <p class="mb-4">Daftar user aplikasi.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data User</h6>
        </div>
        
        <div class="card-body">
            <button class="btn btn-info btn-user" id="addUser" style="margin-bottom: 30px;">Tambah</button>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        include "../db.php";
                        $db = new db;
                        $user = $db->get_allUser();
                        $no = 1;
                        while($row = $user->fetch_array()){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['username']; ?></td>
                            <!-- jangan tampilkan password asli -->
                            <td>******</td>
                            <td>
                                <button class="btn btn-success btn-user" id="editUser" value="<?php echo $row['id']; ?>">Edit</button>
                                <button class="btn btn-danger btn-user" id="deleteUser" value="<?php echo $row['id']; ?>">Delete</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>

<script>
$(document).ready(function(){  
    $("#addUser").click(function(){
        $.ajax({
            url: 'user/add.php',
            type: 'get',
            success: function(data) {
                $('#contentData').html(data);
            }
        });
    });  
});
</script>
