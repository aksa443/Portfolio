<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">KRS</h1>
    <p class="mb-4">Daftar Kartu Rencana Studi (KRS).</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data KRS</h6>
        </div>
        
        <div class="card-body">
            <button class="btn btn-info btn-user" id="addKrs" style="margin-bottom: 30px;">Tambah</button>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Mata Kuliah</th>
                            <th>Dosen</th>
                            <th>Waktu / Ruang</th>
                            <th>Semester</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Mata Kuliah</th>
                            <th>Dosen</th>
                            <th>Waktu / Ruang</th>
                            <th>Semester</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        include "../db.php";
                        $db = new db;
                        $krs = $db->get_allKrs();
                        $no=1;
                        while($row = $krs->fetch_array()){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['nim']; ?></td>
                            <td><?php echo $row['nama_mhs']; ?></td>
                            <td><?php echo $row['nama_matkul']; ?></td>
                            <td><?php echo $row['nama_dosen']; ?></td>
                            <td><?php echo $row['waktu']." / ".$row['ruang']; ?></td>
                            <td><?php echo $row['semester']; ?></td>
                            <td>
                                <button class="btn btn-success btn-user" id="editKrs" value="<?php echo $row['id']; ?>">Edit</button>
                                <button class="btn btn-danger btn-user" id="deleteKrs" value="<?php echo $row['id']; ?>">Delete</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>

<script>
$(document).ready(function(){  
    $("#addKrs").click(function(){
        $.ajax({
            url: 'krs/add.php',
            type: 'get',
            success: function(data) {
                $('#contentData').html(data);
            }
        });
    });  
});
</script>
