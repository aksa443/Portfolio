<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit KRS</h1>
    <p class="mb-4">Form untuk mengubah Kartu Rencana Studi.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form KRS</h6>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">
                <?php
                include "../db.php";
                $id = $_GET['id'];
                $db = new db;

                $krs = $db->get_KrsById($id);
                $row = $krs->fetch_array();

                $mhs = $db->get_allMhs();
                $jadwal = $db->get_allJadwal();
                $semester = $db->get_allSemester();
                ?>
                <form method="POST" id="formEditKrs">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                    <div class="form-group">
                        <label>Mahasiswa</label>
                        <select class="form-control" name="nim">
                            <?php while($m = $mhs->fetch_array()){ ?>
                                <option value="<?php echo $m['nim']; ?>"
                                    <?php if($m['nim'] == $row['nim']) echo "selected"; ?>>
                                    <?php echo $m['nim']." - ".$m['nama']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Jadwal (Matkul - Dosen - Waktu/Ruang)</label>
                        <select class="form-control" name="id_jadwal">
                            <?php while($j = $jadwal->fetch_array()){ ?>
                                <option value="<?php echo $j['id']; ?>"
                                    <?php if($j['id'] == $row['id_jadwal']) echo "selected"; ?>>
                                    <?php echo "[ID ".$j['id']."] ".$j['nama_matkul']." - ".$j['nama_dosen']." (".$j['waktu']." / ".$j['ruang'].")"; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Semester</label>
                        <select class="form-control" name="kd_semester">
                            <?php while($s = $semester->fetch_array()){ ?>
                                <option value="<?php echo $s['kd_semester']; ?>"
                                    <?php if($s['kd_semester'] == $row['kd_semester']) echo "selected"; ?>>
                                    <?php echo $s['kd_semester']." - ".$s['semester']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>
