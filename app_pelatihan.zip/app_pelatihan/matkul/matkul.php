<?php
include "../db.php";
$db = new db;

switch ($_GET['action'])
{
    case 'save':

        $kd_matkul = $_POST['kd_matkul'];
        $nama      = $_POST['nama'];
        $sks       = $_POST['sks'];

        $query = $db->add_matkul($kd_matkul,$nama,$sks);
        if ($query){
            echo "Simpan Matkul Berhasil";
        } else {
            echo "Simpan Matkul Gagal";
        }
    break;

    case 'edit':

        $kd_matkul = $_POST['kd_matkul'];
        $nama      = $_POST['nama'];
        $sks       = $_POST['sks'];
    
        $query = $db->update_matkul($kd_matkul,$nama,$sks);
        if ($query){
            echo "Edit Matkul Berhasil";
        } else {
            echo "Edit Matkul Gagal";
        }
    break;

    case 'delete':

        $kd_matkul = $_POST['kd_matkul'];

        $query = $db->del_matkul($kd_matkul);
        if ($query){
            echo "Hapus Matkul Berhasil";
        } else {
            echo "Hapus Matkul Gagal";
        }
    break;
}
?>
