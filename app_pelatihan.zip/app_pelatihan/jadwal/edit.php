<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Jadwal</h1>
    <p class="mb-4">Form untuk mengubah jadwal perkuliahan.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Jadwal</h6>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">
                <?php
                include "../db.php";
                $id = $_GET['id'];
                $db = new db;

                $jadwal = $db->get_JadwalById($id);
                $row = $jadwal->fetch_array();

                $dosen = $db->get_allDosen();
                $matkul = $db->get_allMatkul();
                ?>
                <form method="POST" id="formEditJadwal">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    
                    <div class="form-group">
                        <label>Dosen</label>
                        <select class="form-control" name="kd_dosen">
                            <?php while($d = $dosen->fetch_array()){ ?>
                                <option value="<?php echo $d['kd_dosen']; ?>"
                                    <?php if($d['kd_dosen'] == $row['kd_dosen']) echo "selected"; ?>>
                                    <?php echo $d['kd_dosen']." - ".$d['nama']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Mata Kuliah</label>
                        <select class="form-control" name="kd_matkul">
                            <?php while($m = $matkul->fetch_array()){ ?>
                                <option value="<?php echo $m['kd_matkul']; ?>"
                                    <?php if($m['kd_matkul'] == $row['kd_matkul']) echo "selected"; ?>>
                                    <?php echo $m['kd_matkul']." - ".$m['nama']." (".$m['sks'].")"; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Waktu</label>
                        <input type="text" class="form-control" name="waktu" value="<?php echo $row['waktu']; ?>">
                    </div>
                    <div class="form-group">
                        <label>Ruang</label>
                        <input type="text" class="form-control" name="ruang" value="<?php echo $row['ruang']; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>
