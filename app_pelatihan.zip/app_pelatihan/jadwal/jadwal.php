<?php
include "../db.php";
$db = new db;

switch ($_GET['action'])
{
    case 'save':
        $kd_dosen  = $_POST['kd_dosen'];
        $kd_matkul = $_POST['kd_matkul'];
        $waktu     = $_POST['waktu'];
        $ruang     = $_POST['ruang'];

        $query = $db->add_jadwal($kd_dosen,$kd_matkul,$waktu,$ruang);
        if ($query){
            echo "Simpan Jadwal Berhasil";
        } else {
            echo "Simpan Jadwal Gagal";
        }
    break;

    case 'edit':
        $id        = $_POST['id'];
        $kd_dosen  = $_POST['kd_dosen'];
        $kd_matkul = $_POST['kd_matkul'];
        $waktu     = $_POST['waktu'];
        $ruang     = $_POST['ruang'];

        $query = $db->update_jadwal($id,$kd_dosen,$kd_matkul,$waktu,$ruang);
        if ($query){
            echo "Edit Jadwal Berhasil";
        } else {
            echo "Edit Jadwal Gagal";
        }
    break;

    case 'delete':
        $id = $_POST['id'];

        $query = $db->del_jadwal($id);
        if ($query){
            echo "Hapus Jadwal Berhasil";
        } else {
            echo "Hapus Jadwal Gagal";
        }
    break;
}
?>
