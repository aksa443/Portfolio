<?php
include "../db.php";
$db = new db;

switch ($_GET['action'])
{
    case 'save':

        $kd_semester = $_POST['kd_semester'];
        $semester    = $_POST['semester'];

        $query = $db->add_semester($kd_semester,$semester);
        if ($query){
            echo "Simpan Semester Berhasil";
        } else {
            echo "Simpan Semester Gagal";
        }
    break;

    case 'edit':

        $kd_semester = $_POST['kd_semester'];
        $semester    = $_POST['semester'];
    
        $query = $db->update_semester($kd_semester,$semester);
        if ($query){
            echo "Edit Semester Berhasil";
        } else {
            echo "Edit Semester Gagal";
        }
    break;

    case 'delete':

        $kd_semester = $_POST['kd_semester'];

        $query = $db->del_semester($kd_semester);
        if ($query){
            echo "Hapus Semester Berhasil";
        } else {
            echo "Hapus Semester Gagal";
        }
    break;
}
?>
