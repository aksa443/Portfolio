<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Semester</h1>
    <p class="mb-4">Form untuk mengubah data semester.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Semester</h6>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">

            <?php
            include "../db.php";
            $kd_semester = $_GET['kd_semester'];
            $db = new db;

            $sem = $db->get_SemesterByKode($kd_semester);
            $row = $sem->fetch_array();
            ?>

            <form method="POST" id="formEditSemester">
                <div class="form-group">
                    <label>Kode Semester</label>
                    <input type="hidden" name="kd_semester" value="<?php echo $row['kd_semester']; ?>">
                    <input type="text" class="form-control" value="<?php echo $row['kd_semester']; ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Nama Semester</label>
                    <input type="text" class="form-control" name="semester" value="<?php echo $row['semester']; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Simpan</button>
            </form>

            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="asset/js/demo/datatables-demo.js"></script>
