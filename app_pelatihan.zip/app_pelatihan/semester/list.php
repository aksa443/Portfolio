<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Semester</h1>
    <p class="mb-4">Daftar semester perkuliahan.</p>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Semester</h6>
        </div>
        
        <div class="card-body">
            <button class="btn btn-info btn-user" id="addSemester" style="margin-bottom: 30px;">Tambah</button>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Semester</th>
                            <th>Nama Semester</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Kode Semester</th>
                            <th>Nama Semester</th>
                            <th>Aksi</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        include "../db.php";
                        $db = new db;
                        $sem = $db->get_allSemester();
                        $no=1;
                        while($row = $sem->fetch_array()){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $row['kd_semester']; ?></td>
                            <td><?php echo $row['semester']; ?></td>
                            <td>
                                <button class="btn btn-success btn-user" id="editSemester" value="<?php echo $row['kd_semester']; ?>">Edit</button>
                                <button class="btn btn-danger btn-user" id="deleteSemester" value="<?php echo $row['kd_semester']; ?>">Delete</button>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Page level plugins -->
<script src="asset/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="asset/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="asset/js/demo/datatables-demo.js"></script>

<script>
$(document).ready(function(){  
    $("#addSemester").click(function(){
        $.ajax({
            url: 'semester/add.php',
            type: 'get',
            success: function(data) {
                $('#contentData').html(data);
            }
        });
    });  
});
</script>
