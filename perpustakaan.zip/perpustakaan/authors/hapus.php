<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();
$id = $_GET['id'] ?? null;
if ($id) {
    $st = $pdo->prepare("DELETE FROM authors WHERE id = :id");
    $st->execute(['id'=>$id]);
}
header('Location: index.php');
exit;
