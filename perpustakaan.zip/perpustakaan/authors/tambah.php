<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($name === '') $errors[] = "Nama harus diisi.";
    if ($email === '') $errors[] = "Email harus diisi.";
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Format email tidak valid.";

    if (empty($errors)) {
        $st = $pdo->prepare("SELECT id FROM authors WHERE email = :email LIMIT 1");
        $st->execute(['email'=>$email]);
        if ($st->fetch()) {
            $errors[] = "Email sudah digunakan.";
        } else {
            $ins = $pdo->prepare("INSERT INTO authors (name, email) VALUES (:name, :email)");
            $ins->execute(['name'=>$name,'email'=>$email]);
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Tambah Author</title></head><body>
  <h2>Tambah Author</h2>
  <p><a href="index.php">Kembali</a></p>

  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Nama<br><input type="text" name="name" value="<?=htmlspecialchars($_POST['name'] ?? '')?>"></label></div>
    <div><label>Email<br><input type="email" name="email" value="<?=htmlspecialchars($_POST['email'] ?? '')?>"></label></div>
    <div><button type="submit">Simpan</button></div>
  </form>
</body></html>
