<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$id = $_GET['id'] ?? null;
if (!$id) { header('Location: index.php'); exit; }

$st = $pdo->prepare("SELECT * FROM authors WHERE id = :id LIMIT 1");
$st->execute(['id'=>$id]);
$author = $st->fetch();
if (!$author) { header('Location: index.php'); exit; }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');

    if ($name === '') $errors[] = "Nama harus diisi.";
    if ($email === '') $errors[] = "Email harus diisi.";
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Format email tidak valid.";

    if (empty($errors)) {
        $st2 = $pdo->prepare("SELECT id FROM authors WHERE email = :email AND id != :id LIMIT 1");
        $st2->execute(['email'=>$email,'id'=>$id]);
        if ($st2->fetch()) {
            $errors[] = "Email sudah digunakan oleh author lain.";
        } else {
            $up = $pdo->prepare("UPDATE authors SET name=:name, email=:email WHERE id=:id");
            $up->execute(['name'=>$name,'email'=>$email,'id'=>$id]);
            header('Location: index.php');
            exit;
        }
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Author</title></head><body>
  <h2>Edit Author</h2>
  <p><a href="index.php">Kembali</a></p>
  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Nama<br><input type="text" name="name" value="<?=htmlspecialchars($_POST['name'] ?? $author['name'])?>"></label></div>
    <div><label>Email<br><input type="email" name="email" value="<?=htmlspecialchars($_POST['email'] ?? $author['email'])?>"></label></div>
    <div><button type="submit">Update</button></div>
  </form>
</body></html>
