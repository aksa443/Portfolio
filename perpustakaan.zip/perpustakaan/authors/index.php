<?php
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$stmt = $pdo->query("SELECT * FROM authors ORDER BY id DESC");
$authors = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Authors</title></head><body>
  <h2>Daftar Authors</h2>
  <p><a href="../dashboard.php">Dashboard</a> | <a href="tambah.php">Tambah Author</a></p>
  <table border="1" cellpadding="6" cellspacing="0">
    <tr><th>ID</th><th>Nama</th><th>Email</th><th>Created</th><th>Aksi</th></tr>
    <?php if ($authors): foreach ($authors as $a): ?>
      <tr>
        <td><?=htmlspecialchars($a['id'])?></td>
        <td><?=htmlspecialchars($a['name'])?></td>
        <td><?=htmlspecialchars($a['email'])?></td>
        <td><?=htmlspecialchars($a['created_at'])?></td>
        <td>
          <a href="edit.php?id=<?= $a['id'] ?>">Edit</a> |
          <a href="hapus.php?id=<?= $a['id'] ?>" onclick="return confirm('Hapus author?')">Hapus</a>
        </td>
      </tr>
    <?php endforeach; else: ?>
      <tr><td colspan="5">Belum ada data.</td></tr>
    <?php endif; ?>
  </table>
</body></html>
