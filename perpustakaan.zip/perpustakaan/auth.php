<?php

// auth.php (potongan)
session_start();

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$scriptDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
$loginPath = ($scriptDir === '' || $scriptDir === '/' ) ? '/login.php' : $scriptDir . '/login.php';

$public_paths = [
    $loginPath,
    $scriptDir . '/logout.php'
];

// jika belum login dan bukan halaman publik -> redirect
if (!isset($_SESSION['user'])) {
    // jika request saat ini bukan halaman publik
    if (!in_array($path, $public_paths)) {
        // simpan redirect lalu pindah ke login
        $_SESSION['after_login_redirect'] = $path . (isset($_SERVER['QUERY_STRING']) && $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '');
        header('Location: ' . $loginPath);
        exit;
    }
}
