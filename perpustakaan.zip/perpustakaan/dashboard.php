<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
$pdo = DB::getInstance()->getConnection();

$counts = [];
$tables = ['authors', 'borrowers', 'books', 'loans'];
foreach ($tables as $t) {
    $stmt = $pdo->query("SELECT COUNT(*) as cnt FROM {$t}");
    $r = $stmt->fetch();
    $counts[$t] = $r ? $r['cnt'] : 0;
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard - APP_PERPUSTAKAAN</title>
<style>body{font-family:Arial;max-width:900px;margin:20px auto} .card{padding:12px;border:1px solid #ddd;margin:8px 0;border-radius:6px}</style>
</head>
<body>
  <h1>Dashboard APP_PERPUSTAKAAN</h1>
  <p>
    <a href="authors/index.php">Authors</a> |
    <a href="books/index.php">Books</a> |
    <a href="loans/index.php">Loans</a> |
    <a href="borrowers/index.php">Borrowers</a>
  </p>

  <div class="card"><strong>Authors:</strong> <?= $counts['authors'] ?></div>
  <div class="card"><strong>Borrowers:</strong> <?= $counts['borrowers'] ?></div>
  <div class="card"><strong>Books:</strong> <?= $counts['books'] ?></div>
  <div class="card"><strong>Loans:</strong> <?= $counts['loans'] ?></div>
</body>
</html>
