<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$borrowers = $pdo->query("SELECT id, name FROM borrowers ORDER BY name")->fetchAll();
$books = $pdo->query("SELECT id, title FROM books ORDER BY title")->fetchAll();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrower_id = intval($_POST['borrower_id'] ?? 0);
    $book_id = intval($_POST['book_id'] ?? 0);
    $return_date = trim($_POST['return_date'] ?? null);

    if (!$borrower_id) $errors[] = "Pilih borrower.";
    if (!$book_id) $errors[] = "Pilih book.";

    if (empty($errors)) {
        $st = $pdo->prepare("SELECT id FROM loans WHERE borrower_id=:b AND book_id=:bk LIMIT 1");
        $st->execute(['b'=>$borrower_id,'bk'=>$book_id]);
        if ($st->fetch()) $errors[] = "Loan untuk borrower dan buku tersebut sudah ada.";
    }

    if (empty($errors)) {
        $ins = $pdo->prepare("INSERT INTO loans (borrower_id, book_id, return_date) VALUES (:b, :bk, :r)");
        $ins->execute(['b'=>$borrower_id,'bk'=>$book_id,'r'=>$return_date]);
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Tambah Loan</title></head><body>
  <h2>Tambah Loan</h2>
  <p><a href="index.php">Kembali</a></p>

  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Borrower<br>
      <select name="borrower_id">
        <option value="">-- Pilih --</option>
        <?php foreach($borrowers as $m): ?>
          <option value="<?=$m['id']?>" <?= (isset($_POST['borrower_id']) && $_POST['borrower_id']==$m['id'])?'selected':'' ?>><?=htmlspecialchars($m['name'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Book<br>
      <select name="book_id">
        <option value="">-- Pilih --</option>
        <?php foreach($books as $j): ?>
          <option value="<?=$j['id']?>" <?= (isset($_POST['book_id']) && $_POST['book_id']==$j['id'])?'selected':'' ?>><?=htmlspecialchars($j['title'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Return Date (YYYY-MM-DD, optional)<br><input type="date" name="return_date" value="<?=htmlspecialchars($_POST['return_date'] ?? '')?>"></label></div>

    <div><button type="submit">Simpan</button></div>
  </form>
</body></html>
