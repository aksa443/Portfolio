<?php
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$stmt = $pdo->query("SELECT l.*, b.name as borrower_name, bk.title as book_title, a.name as author_name
FROM loans l
JOIN borrowers b ON l.borrower_id = b.id
JOIN books bk ON l.book_id = bk.id
JOIN authors a ON bk.author_id = a.id
ORDER BY l.id DESC");
$loans = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Loans</title></head><body>
  <h2>Daftar Loans</h2>
  <p><a href="../dashboard.php">Dashboard</a> | <a href="tambah.php">Tambah Loan</a></p>

  <table border="1" cellpadding="6">
    <tr><th>ID</th><th>Borrower</th><th>Book</th><th>Author</th><th>Return Date</th><th>Aksi</th></tr>
    <?php if ($loans): foreach($loans as $r): ?>
      <tr>
        <td><?=htmlspecialchars($r['id'])?></td>
        <td><?=htmlspecialchars($r['borrower_name'])?></td>
        <td><?=htmlspecialchars($r['book_title'])?></td>
        <td><?=htmlspecialchars($r['author_name'])?></td>
        <td><?=htmlspecialchars($r['return_date'])?></td>
        <td><a href="edit.php?id=<?=$r['id']?>">Edit</a> | <a href="hapus.php?id=<?=$r['id']?>" onclick="return confirm('Hapus loan?')">Hapus</a></td>
      </tr>
    <?php endforeach; else: ?>
      <tr><td colspan="6">Belum ada loans.</td></tr>
    <?php endif; ?>
  </table>
</body></html>
