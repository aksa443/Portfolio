<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$id = $_GET['id'] ?? null;
if (!$id) { header('Location: index.php'); exit; }

$st = $pdo->prepare("SELECT * FROM loans WHERE id = :id LIMIT 1");
$st->execute(['id'=>$id]);
$loan = $st->fetch();
if (!$loan) { header('Location: index.php'); exit; }

$borrowers = $pdo->query("SELECT id, name FROM borrowers ORDER BY name")->fetchAll();
$books = $pdo->query("SELECT id, title FROM books ORDER BY title")->fetchAll();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $borrower_id = intval($_POST['borrower_id'] ?? 0);
    $book_id = intval($_POST['book_id'] ?? 0);
    $return_date = trim($_POST['return_date'] ?? null);

    if (!$borrower_id) $errors[] = "Pilih borrower.";
    if (!$book_id) $errors[] = "Pilih book.";

    if (empty($errors)) {
        $st2 = $pdo->prepare("SELECT id FROM loans WHERE borrower_id=:b AND book_id=:bk AND id != :id LIMIT 1");
        $st2->execute(['b'=>$borrower_id,'bk'=>$book_id,'id'=>$id]);
        if ($st2->fetch()) $errors[] = "Loan untuk borrower dan buku tersebut sudah ada.";
    }

    if (empty($errors)) {
        $up = $pdo->prepare("UPDATE loans SET borrower_id=:b, book_id=:bk, return_date=:r WHERE id=:id");
        $up->execute(['b'=>$borrower_id,'bk'=>$book_id,'r'=>$return_date,'id'=>$id]);
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Loan</title></head><body>
  <h2>Edit Loan</h2>
  <p><a href="index.php">Kembali</a></p>

  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Borrower<br>
      <select name="borrower_id">
        <option value="">-- Pilih --</option>
        <?php foreach($borrowers as $m): $sel = (isset($_POST['borrower_id'])?$_POST['borrower_id']:$loan['borrower_id'])==$m['id']; ?>
          <option value="<?=$m['id']?>" <?= $sel ? 'selected' : '' ?>><?=htmlspecialchars($m['name'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Book<br>
      <select name="book_id">
        <option value="">-- Pilih --</option>
        <?php foreach($books as $j): $selj = (isset($_POST['book_id'])?$_POST['book_id']:$loan['book_id'])==$j['id']; ?>
          <option value="<?=$j['id']?>" <?= $selj ? 'selected' : '' ?>><?=htmlspecialchars($j['title'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Return Date (YYYY-MM-DD, optional)<br><input type="date" name="return_date" value="<?=htmlspecialchars($_POST['return_date'] ?? $loan['return_date'])?>"></label></div>

    <div><button type="submit">Update</button></div>
  </form>
</body></html>
