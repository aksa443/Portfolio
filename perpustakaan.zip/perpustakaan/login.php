<?php
// login.php
session_start();

// Jika sudah login, langsung ke dashboard
if (isset($_SESSION['user'])) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '') $errors[] = "Username harus diisi.";
    if ($password === '') $errors[] = "Password harus diisi.";

    // kredensial admin (contoh sederhana)
    $ADMIN_USER = 'admin';
    $ADMIN_PASS = 'admin123';

    if (empty($errors)) {
        if ($username === $ADMIN_USER && $password === $ADMIN_PASS) {
            // login sukses
            $_SESSION['user'] = $username;
            // redirect ke halaman semula jika ada
            if (!empty($_SESSION['after_login_redirect'])) {
                $go = $_SESSION['after_login_redirect'];
                unset($_SESSION['after_login_redirect']);
                header("Location: $go");
            } else {
                header('Location: dashboard.php');
            }
            exit;
        } else {
            $errors[] = "Username atau password salah.";
        }
    }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login - APP_PERPUSTAKAAN</title>
  <style>body{font-family:Arial;max-width:420px;margin:80px auto} form{border:1px solid #ddd;padding:18px;border-radius:8px} input{width:100%;padding:8px;margin:6px 0} .err{color:#a94442;background:#f2dede;padding:8px;border-radius:4px;margin-bottom:8px}</style>
</head>
<body>
  <h2>Login</h2>

  <?php if (!empty($errors)): ?>
    <div class="err"><ul><?php foreach($errors as $e) echo '<li>' . htmlspecialchars($e) . '</li>'; ?></ul></div>
  <?php endif; ?>

  <form method="post" action="">
    <label>Username<br><input type="text" name="username" value="<?=htmlspecialchars($_POST['username'] ?? '')?>"></label>
    <label>Password<br><input type="password" name="password"></label>
    <div style="margin-top:8px">
      <button type="submit">Login</button>
    </div>
  </form>

  <p style="margin-top:12px"><strong>Test account:</strong> admin / admin123</p>
</body>
</html>
