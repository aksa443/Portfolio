<?php
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$stmt = $pdo->query("SELECT b.*, a.name as author_name FROM books b JOIN authors a ON b.author_id = a.id ORDER BY b.id DESC");
$books = $stmt->fetchAll();
?>
<!doctype html><html><head><meta charset="utf-8"><title>Books</title></head><body>
  <h2>Daftar Books</h2>
  <p><a href="../dashboard.php">Dashboard</a> | <a href="tambah.php">Tambah Book</a></p>

  <table border="1" cellpadding="6">
    <tr><th>ID</th><th>Title</th><th>Author</th><th>ISBN</th><th>Tahun</th><th>Aksi</th></tr>
    <?php if ($books): foreach($books as $b): ?>
      <tr>
        <td><?=htmlspecialchars($b['id'])?></td>
        <td><?=htmlspecialchars($b['title'])?></td>
        <td><?=htmlspecialchars($b['author_name'])?></td>
        <td><?=htmlspecialchars($b['isbn'])?></td>
        <td><?=htmlspecialchars($b['published_year'])?></td>
        <td><a href="edit.php?id=<?=$b['id']?>">Edit</a> | <a href="hapus.php?id=<?=$b['id']?>" onclick="return confirm('Hapus book?')">Hapus</a></td>
      </tr>
    <?php endforeach; else: ?>
      <tr><td colspan="6">Belum ada buku.</td></tr>
    <?php endif; ?>
  </table>
</body></html>
