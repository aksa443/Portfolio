<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$id = $_GET['id'] ?? null;
if (!$id) { header('Location: index.php'); exit; }

$st = $pdo->prepare("SELECT * FROM books WHERE id = :id LIMIT 1");
$st->execute(['id'=>$id]);
$book = $st->fetch();
if (!$book) { header('Location: index.php'); exit; }

$authors = $pdo->query("SELECT id, name FROM authors ORDER BY name")->fetchAll();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $author_id = intval($_POST['author_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $yr = trim($_POST['published_year'] ?? '');

    if (!$author_id) $errors[] = "Pilih author.";
    if ($title === '') $errors[] = "Title harus diisi.";

    if (empty($errors)) {
        $up = $pdo->prepare("UPDATE books SET author_id=:author_id, title=:title, isbn=:isbn, published_year=:yr WHERE id=:id");
        $up->execute(['author_id'=>$author_id,'title'=>$title,'isbn'=>$isbn,'yr'=>$yr,'id'=>$id]);
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Edit Book</title></head><body>
  <h2>Edit Book</h2>
  <p><a href="index.php">Kembali</a></p>

  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Author<br>
      <select name="author_id">
        <option value="">-- Pilih --</option>
        <?php foreach($authors as $a): $sel = (isset($_POST['author_id'])?$_POST['author_id']:$book['author_id'])==$a['id']; ?>
          <option value="<?=$a['id']?>" <?= $sel ? 'selected' : '' ?>><?=htmlspecialchars($a['name'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Title<br><input type="text" name="title" value="<?=htmlspecialchars($_POST['title'] ?? $book['title'])?>"></label></div>
    <div><label>ISBN (opsional)<br><input type="text" name="isbn" value="<?=htmlspecialchars($_POST['isbn'] ?? $book['isbn'])?>"></label></div>
    <div><label>Tahun Terbit (opsional)<br><input type="text" name="published_year" value="<?=htmlspecialchars($_POST['published_year'] ?? $book['published_year'])?>"></label></div>
    <div><button type="submit">Update</button></div>
  </form>
</body></html>
