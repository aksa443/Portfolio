<?php
require_once __DIR__ . '/../db.php';
$pdo = DB::getInstance()->getConnection();

$authors = $pdo->query("SELECT id, name FROM authors ORDER BY name")->fetchAll();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $author_id = intval($_POST['author_id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $yr = trim($_POST['published_year'] ?? '');

    if (!$author_id) $errors[] = "Pilih author.";
    if ($title === '') $errors[] = "Title harus diisi.";

    if (empty($errors)) {
        $ins = $pdo->prepare("INSERT INTO books (author_id, title, isbn, published_year) VALUES (:author_id, :title, :isbn, :yr)");
        $ins->execute(['author_id'=>$author_id,'title'=>$title,'isbn'=>$isbn,'yr'=>$yr]);
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><title>Tambah Book</title></head><body>
  <h2>Tambah Book</h2>
  <p><a href="index.php">Kembali</a></p>

  <?php if ($errors): ?><div style="color:red"><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div><?php endif; ?>

  <form method="post" action="">
    <div><label>Author<br>
      <select name="author_id">
        <option value="">-- Pilih --</option>
        <?php foreach($authors as $a): ?>
          <option value="<?=$a['id']?>" <?= (isset($_POST['author_id']) && $_POST['author_id']==$a['id'])?'selected':'' ?>><?=htmlspecialchars($a['name'])?></option>
        <?php endforeach; ?>
      </select>
    </label></div>

    <div><label>Title<br><input type="text" name="title" value="<?=htmlspecialchars($_POST['title'] ?? '')?>"></label></div>
    <div><label>ISBN (opsional)<br><input type="text" name="isbn" value="<?=htmlspecialchars($_POST['isbn'] ?? '')?>"></label></div>
    <div><label>Tahun Terbit (opsional)<br><input type="text" name="published_year" value="<?=htmlspecialchars($_POST['published_year'] ?? '')?>"></label></div>
    <div><button type="submit">Simpan</button></div>
  </form>
</body></html>
